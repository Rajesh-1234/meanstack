

// $("#parent :nth-child(1)").css("color","blue");

let x = document.querySelector("#parent");

console.log(x);
